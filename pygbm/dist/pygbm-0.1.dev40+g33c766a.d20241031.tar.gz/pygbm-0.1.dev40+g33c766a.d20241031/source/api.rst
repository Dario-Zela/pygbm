API
===

.. autosummary::
   :toctree: generated

   pygbm.gbm_simulator