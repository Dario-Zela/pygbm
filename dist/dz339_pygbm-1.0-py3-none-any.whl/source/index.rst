.. mdinclude:: ../README.md

Check out the :doc:`usage` section for further information, including
how to :ref:`installation` the project.

Contents
--------

.. toctree::

   Home <self>
   usage
   api